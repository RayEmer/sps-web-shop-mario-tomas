export interface Tienda {
    sucursal: string;
    direccion: string;
  }